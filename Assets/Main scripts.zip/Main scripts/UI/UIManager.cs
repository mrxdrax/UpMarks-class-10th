using UnityEngine;

public class UIManager : MonoBehaviour
{
    public void ShowPanel(GameObject panel)
    {
        HideAllPanels();
        panel.SetActive(true);
    }

    public void HidePanel(GameObject panel)
    {
        panel.SetActive(false);
    }

    private void HideAllPanels()
    {
        // Get all panels from children and disable them
        // Safely handles all RectTransforms (UI elements)
        foreach (var rectTransform in GetComponentsInChildren<RectTransform>(true))
        {
            if (rectTransform != transform && rectTransform.CompareTag("Panel"))
            {
                rectTransform.gameObject.SetActive(false);
            }
        }
    }
}
